CREATE TABLE public.letters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT NOT NULL UNIQUE,
  answers JSONB NOT NULL DEFAULT '{}'::jsonb,
  message TEXT NOT NULL DEFAULT '',
  contact_email TEXT,
  reply TEXT,
  replied_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE ON public.letters TO service_role;

ALTER TABLE public.letters ENABLE ROW LEVEL SECURITY;

-- No policies on purpose: letters are only read/written by trusted server code
-- (service role), never directly from the browser. Reading a reply requires the
-- secret code; listing letters requires the supporters' password.CREATE TABLE public.letter_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  letter_id UUID NOT NULL REFERENCES public.letters(id) ON DELETE CASCADE,
  sender TEXT NOT NULL CHECK (sender IN ('writer','support')),
  body TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT ALL ON public.letter_messages TO service_role;
ALTER TABLE public.letter_messages ENABLE ROW LEVEL SECURITY;
CREATE INDEX letter_messages_letter_idx ON public.letter_messages(letter_id, created_at);
-- Move existing single replies into the conversation
INSERT INTO public.letter_messages (letter_id, sender, body, created_at)
SELECT id, 'support', reply, COALESCE(replied_at, now()) FROM public.letters WHERE reply IS NOT NULL;ALTER TABLE public.letters ADD COLUMN student_name TEXT, ADD COLUMN student_class TEXT;