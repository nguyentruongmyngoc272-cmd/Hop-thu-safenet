CREATE TABLE public.letter_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  letter_id UUID NOT NULL REFERENCES public.letters(id) ON DELETE CASCADE,
  sender TEXT NOT NULL CHECK (sender IN ('writer','support')),
  body TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT ALL ON public.letter_messages TO service_role;
ALTER TABLE public.letter_messages ENABLE ROW LEVEL SECURITY;
CREATE INDEX letter_messages_letter_idx ON public.letter_messages(letter_id, created_at);
-- Move existing single replies into the conversation
INSERT INTO public.letter_messages (letter_id, sender, body, created_at)
SELECT id, 'support', reply, COALESCE(replied_at, now()) FROM public.letters WHERE reply IS NOT NULL;