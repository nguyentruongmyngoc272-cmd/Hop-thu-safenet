# Hộp thư SafeNet — Hướng dẫn tự đưa lên mạng

1. **Supabase** (supabase.com): tạo dự án mới (vùng Singapore) → SQL Editor → dán toàn bộ file `safenet-database-setup.sql` → Run. Vào Project Settings → API, chép Project URL, anon key, service_role key.
2. **GitHub**: tạo repository `safenet-project`, tải toàn bộ thư mục này lên (dùng GitHub Desktop → Add existing repository → Publish).
3. **Vercel** (vercel.com): đăng nhập bằng GitHub → Import repo → thêm các biến trong `.env.example` (điền giá trị thật) → Deploy.
4. **Google**: vào Google Search Console, thêm địa chỉ web, bấm "Yêu cầu lập chỉ mục".

Mật khẩu khu vực người hỗ trợ (/ho-tro) là giá trị SITE_PASSWORD.
