export type Option = { id: string; label: string; hint?: string };

export type Question = {
  key: string;
  eyebrow: string;
  title: string;
  subtitle: string;
  multi: boolean;
  options: Option[];
};

export const QUESTIONS: Question[] = [
  {
    key: "reason",
    eyebrow: "Câu hỏi 1 / 4",
    title: "Bạn đến đây vì điều gì?",
    subtitle: "Chọn điều gần nhất với bạn. Không có câu trả lời sai.",
    multi: false,
    options: [
      { id: "victim", label: "Tôi đang bị bắt nạt trực tuyến" },
      { id: "bystander", label: "Tôi lo lắng cho một người thân hoặc bạn bè" },
      { id: "learn", label: "Tôi muốn tìm hiểu thêm về bắt nạt trực tuyến" },
    ],
  },
  {
    key: "type",
    eyebrow: "Câu hỏi 2 / 4",
    title: "Bạn đang gặp vấn đề bắt nạt trực tuyến như thế nào?",
    subtitle: "Bạn có thể chọn nhiều điều — kể cả những điều còn mơ hồ.",
    multi: true,
    options: [
      { id: "comments", label: "Bị bình luận ác ý, chửi bới trên mạng" },
      { id: "rumors", label: "Bị lan truyền tin đồn, hình ảnh hoặc thông tin riêng tư" },
      { id: "threats", label: "Bị đe dọa, khủng bố tinh thần" },
      { id: "excluded", label: "Bị cô lập, loại khỏi nhóm trò chuyện" },
      { id: "stalking", label: "Bị theo dõi, quấy rối liên tục" },
      { id: "unsure", label: "Tôi chưa chắc — chỉ cảm thấy không an toàn" },
    ],
  },
  {
    key: "duration",
    eyebrow: "Câu hỏi 3 / 4",
    title: "Tình trạng này kéo dài bao lâu rồi?",
    subtitle: "Bất kể lâu hay mới, điều bạn đang chịu đựng đều đáng được quan tâm.",
    multi: false,
    options: [
      { id: "today", label: "Vừa mới xảy ra" },
      { id: "weeks", label: "Vài tuần nay" },
      { id: "months", label: "Vài tháng nay" },
      { id: "years", label: "Đã rất lâu rồi" },
    ],
  },
  {
    key: "feelings",
    eyebrow: "Câu hỏi 4 / 4",
    title: "Điều này khiến bạn cảm thấy thế nào?",
    subtitle: "Hãy chọn những cảm xúc đang ở trong bạn. Chọn nhiều cảm xúc cũng được.",
    multi: true,
    options: [
      { id: "anxious", label: "Lo lắng" },
      { id: "sad", label: "Buồn" },
      { id: "scared", label: "Sợ hãi" },
      { id: "tired", label: "Mệt mỏi" },
      { id: "lonely", label: "Cô đơn" },
      { id: "angry", label: "Tức giận" },
      { id: "numb", label: "Tê liệt, không biết phải làm gì" },
      { id: "okay", label: "Vẫn ổn, chỉ muốn được lắng nghe" },
    ],
  },
];

export function optionLabel(key: string, id: string): string {
  const question = QUESTIONS.find((q) => q.key === key);
  return question?.options.find((o) => o.id === id)?.label ?? id;
}
