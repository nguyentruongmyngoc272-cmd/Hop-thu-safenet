import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { useSession } from "@tanstack/react-start/server";
import { createHash, createHmac, randomInt, timingSafeEqual } from "node:crypto";

/* ---------------- Supporters' shared-password gate ---------------- */

function sessionConfig() {
  return {
    password: process.env['SESSION_SECRET']!, // server-only; encrypts the session cookie
    name: "safenet-support-gate",
    maxAge: 60 * 60 * 24 * 7, // 7 days
    // "none" so the cookie also works when the site is shown inside a frame (preview).
    cookie: { httpOnly: true, secure: true, sameSite: "none" as const, path: "/" },
  };
}

type GateSession = { unlocked?: boolean };

async function getSession() {
  return useSession<GateSession>(sessionConfig());
}

// Hash both sides to equal-length digests first: timingSafeEqual throws on a
// length mismatch, and the raw length itself would leak through timing.
function passwordMatches(input: string, expected: string): boolean {
  const a = createHash("sha256").update(input, "utf8").digest();
  const b = createHash("sha256").update(expected, "utf8").digest();
  return timingSafeEqual(a, b);
}

// Signed token fallback: phones (e.g. Safari) block cookies inside the preview
// frame, so the browser also keeps this token and sends it with each request.
function signToken(exp: number): string {
  const sig = createHmac("sha256", process.env['SESSION_SECRET']!).update(String(exp)).digest("hex");
  return `${exp}.${sig}`;
}
function tokenValid(token?: string | null): boolean {
  if (!token) return false;
  const [expStr] = token.split(".");
  const exp = Number(expStr);
  if (!exp || exp < Date.now()) return false;
  const a = createHash("sha256").update(token).digest();
  const b = createHash("sha256").update(signToken(exp)).digest();
  return timingSafeEqual(a, b);
}
async function isUnlocked(token?: string | null): Promise<boolean> {
  if (tokenValid(token)) return true;
  try {
    const session = await getSession();
    return Boolean(session.data.unlocked);
  } catch {
    return false;
  }
}
const tokenInput = z.object({ token: z.string().max(200).optional().nullable() });

export const getSupportState = createServerFn({ method: "POST" })
  .inputValidator((data) => tokenInput.parse(data ?? {}))
  .handler(async ({ data }) => ({ unlocked: await isUnlocked(data.token) }));

export const unlockSupport = createServerFn({ method: "POST" })
  .inputValidator((data: { password: string }) => z.object({ password: z.string() }).parse(data))
  .handler(async ({ data }) => {
    const expected = process.env['SITE_PASSWORD'];
    if (!expected) throw new Error("SITE_PASSWORD is not set");
    if (!passwordMatches(data.password, expected)) {
      return { ok: false as const };
    }
    try {
      const session = await getSession();
      await session.update({ unlocked: true });
    } catch {}
    return { ok: true as const, token: signToken(Date.now() + 7 * 24 * 3600 * 1000) };
  });

export const lockSupport = createServerFn({ method: "POST" }).handler(async () => {
  const session = await getSession();
  await session.clear();
  return { ok: true as const };
});

/* ---------------- Letters ---------------- */

const ALPHABET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ"; // no ambiguous 0/O, 1/I

function generateCode(): string {
  let s = "";
  for (let i = 0; i < 6; i++) s += ALPHABET[randomInt(ALPHABET.length)];
  return `SN-${s}`;
}

function normalizeCode(input: string): string | null {
  const cleaned = input.trim().toUpperCase().replace(/\s+/g, "");
  if (!cleaned) return null;
  const withPrefix = cleaned.startsWith("SN-") ? cleaned : `SN-${cleaned}`;
  const body = withPrefix.slice(3);
  return body.length >= 4 && body.length <= 8 && /^[0-9A-Z-]+$/.test(withPrefix) ? withPrefix : null;
}

const sealInput = z.object({
  answers: z.record(z.string(), z.array(z.string())).default({}),
  message: z.string().max(1500).default(""),
  contactEmail: z.string().trim().email().optional().nullable(),
  studentName: z.string().trim().max(80).optional().nullable(),
  studentClass: z.string().trim().max(20).optional().nullable(),
});

export const sealLetter = createServerFn({ method: "POST" })
  .inputValidator((data) => sealInput.parse(data))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const contactEmail = data.contactEmail ? data.contactEmail.toLowerCase() : null;

    for (let attempt = 0; attempt < 5; attempt++) {
      const code = generateCode();
      const { data: row, error } = await supabaseAdmin
        .from("letters")
        .insert({
          code,
          answers: data.answers,
          message: data.message,
          contact_email: contactEmail,
          student_name: data.studentName || null,
          student_class: data.studentClass || null,
        })
        .select("code")
        .single();

      if (!error && row) {
        return { ok: true as const, code: row.code, hasEmail: Boolean(contactEmail) };
      }
      // 23505 = unique violation on the code; retry with a fresh code.
      if (error && error.code !== "23505") {
        console.error("[sealLetter] insert failed:", error.message);
        return { ok: false as const };
      }
    }
    console.error("[sealLetter] could not generate a unique code");
    return { ok: false as const };
  });

export type ThreadMessage = { sender: "writer" | "support"; body: string; at: string };

async function loadThreads(ids: string[]) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const map = new Map<string, ThreadMessage[]>();
  if (ids.length === 0) return map;
  const { data } = await supabaseAdmin
    .from("letter_messages")
    .select("letter_id, sender, body, created_at")
    .in("letter_id", ids)
    .order("created_at", { ascending: true });
  for (const m of data ?? []) {
    const list = map.get(m.letter_id) ?? [];
    list.push({ sender: m.sender as "writer" | "support", body: m.body, at: m.created_at });
    map.set(m.letter_id, list);
  }
  return map;
}

const lookupInput = z.object({ code: z.string().min(4).max(20) });

export const lookupLetter = createServerFn({ method: "POST" })
  .inputValidator((data) => lookupInput.parse(data))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const code = normalizeCode(data.code);
    if (!code) return { found: false as const };

    const { data: row, error } = await supabaseAdmin
      .from("letters")
      .select("id, code, message, created_at")
      .eq("code", code)
      .maybeSingle();

    if (error || !row) return { found: false as const };
    const threads = await loadThreads([row.id]);
    const thread: ThreadMessage[] = [
      { sender: "writer", body: row.message, at: row.created_at },
      ...(threads.get(row.id) ?? []),
    ];
    return { found: true as const, code: row.code as string, thread };
  });

const writerInput = z.object({
  code: z.string().min(4).max(20),
  body: z.string().trim().min(1).max(1500),
});

export const sendWriterMessage = createServerFn({ method: "POST" })
  .inputValidator((data) => writerInput.parse(data))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const code = normalizeCode(data.code);
    if (!code) return { ok: false as const };
    const { data: row } = await supabaseAdmin
      .from("letters").select("id").eq("code", code).maybeSingle();
    if (!row) return { ok: false as const };
    const { error } = await supabaseAdmin
      .from("letter_messages")
      .insert({ letter_id: row.id, sender: "writer", body: data.body });
    if (error) {
      console.error("[sendWriterMessage]", error.message);
      return { ok: false as const };
    }
    return { ok: true as const };
  });

export const listLetters = createServerFn({ method: "POST" })
  .inputValidator((data) => tokenInput.parse(data ?? {}))
  .handler(async ({ data: input }) => {
  if (!(await isUnlocked(input.token))) return [];
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const { data, error } = await supabaseAdmin
    .from("letters")
    .select("id, code, answers, message, contact_email, student_name, student_class, created_at")
    .order("created_at", { ascending: false })
    .limit(200);

  if (error) {
    console.error("[listLetters]", error.message);
    return [];
  }
  const rows = data ?? [];
  const threads = await loadThreads(rows.map((r) => r.id));
  const result = rows.map((r) => {
    const thread: ThreadMessage[] = [
      { sender: "writer", body: r.message, at: r.created_at },
      ...(threads.get(r.id) ?? []),
    ];
    const last = thread[thread.length - 1]!;
    return { ...r, thread, lastAt: last.at, awaitingReply: last.sender === "writer" };
  });
  // Most recent activity first, so a writer's new message brings their letter to the top.
  result.sort((a, b) => b.lastAt.localeCompare(a.lastAt));
  return result;
});

const replyInput = z.object({ id: z.string().min(10), reply: z.string().trim().min(1).max(4000), token: z.string().max(200).optional().nullable() });

export const replyToLetter = createServerFn({ method: "POST" })
  .inputValidator((data) => replyInput.parse(data))
  .handler(async ({ data }) => {
    if (!(await isUnlocked(data.token))) return { ok: false as const };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { error } = await supabaseAdmin
      .from("letter_messages")
      .insert({ letter_id: data.id, sender: "support", body: data.reply });

    if (error) {
      console.error("[replyToLetter]", error.message);
      return { ok: false as const };
    }
    return { ok: true as const };
  });

export const deleteLetter = createServerFn({ method: "POST" })
  .inputValidator((data) => z.object({ id: z.string().min(10), token: z.string().max(200).optional().nullable() }).parse(data))
  .handler(async ({ data }) => {
    if (!(await isUnlocked(data.token))) return { ok: false as const };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("letters").delete().eq("id", data.id);
    if (error) {
      console.error("[deleteLetter]", error.message);
      return { ok: false as const };
    }
    return { ok: true as const };
  });
