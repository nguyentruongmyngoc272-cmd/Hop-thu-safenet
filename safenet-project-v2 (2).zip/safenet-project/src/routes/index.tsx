import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import tipsKindness from "@/assets/tips-kindness.png";
import tipsThink from "@/assets/tips-think.png";
import tipsPrivacy from "@/assets/tips-privacy.png";
import tipsNoshare from "@/assets/tips-noshare.png";
import learnWhat from "@/assets/learn-what.png";
import learnForms from "@/assets/learn-forms.png";
import learnBystander from "@/assets/learn-bystander.png";
import learnProtect from "@/assets/learn-protect.png";
import { sealLetter } from "@/lib/letters.functions";
import { QUESTIONS, type Question } from "@/lib/questions";
import {
  ArrowLeft,
  Ban,
  Camera,
  HeartHandshake,
  Lock,
  Mail,
  MailOpen,
  PenLine,
  Phone,
  RotateCcw,
  ShieldAlert,
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Hộp thư SafeNet — Không gian an toàn cho bạn" },
      {
        name: "description",
        content:
          "Hộp thư an toàn, bảo mật dành cho người đang gặp bắt nạt trực tuyến. Trả lời vài câu hỏi, viết cảm nhận của bạn và nhận ngay các giải pháp hỗ trợ phù hợp.",
      },
      { property: "og:title", content: "Hộp thư SafeNet — Không gian an toàn cho bạn" },
      {
        property: "og:description",
        content:
          "Chia sẻ thầm lặng, được bảo mật tuyệt đối. SafeNet lắng nghe và đồng hành cùng bạn.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const SUPPORTS = [
  {
    name: "Nguyễn Trương Mỹ Ngọc",
    role: "Người hỗ trợ của Hộp thư SafeNet",
    initial: "M",
    email: "nguyentruongmyngoc272@gmail.com",
  },
  {
    name: "Đinh Nguyễn Tường Vy",
    role: "Người hỗ trợ của Hộp thư SafeNet",
    initial: "T",
    email: "Tuongvyvy429@gmail.com",
  },
];

const supportMailto = (email: string) =>
  `mailto:${email}?subject=${encodeURIComponent("Nhắn gửi người hỗ trợ SafeNet")}`;

const TIPS: { image: string; alt: string; title: string; hook: string; points: string[] }[] = [
  {
    image: tipsKindness,
    alt: "Bạn trẻ mỉm cười nhắn tin tử tế, những trái tim bay lên từ màn hình",
    title: "Nhắn tin với lòng tốt",
    hook: "Phía sau mỗi màn hình là một người thật, đang đọc từng dòng của bạn.",
    points: [
      "Hãy nói lời cảm ơn, lời động viên — một bình luận tử tế có thể làm ngày của ai đó sáng lên.",
      "Trước khi bình luận, hỏi mình: câu này có làm ai buồn không?",
      "Thấy ai đó bị chê bai thì đừng tham gia — hãy nhắn riêng hỏi thăm họ.",
      "Không dùng lời miệt thị ngoại hình, vùng miền hay gia đình của bất kỳ ai.",
    ],
  },
  {
    image: tipsThink,
    alt: "Bạn trẻ suy tư trước khi bấm nút gửi, bong bóng suy nghĩ lơ lửng trên đầu",
    title: "Dừng 3 giây trước khi gửi",
    hook: "Cơn giận qua rất nhanh, nhưng lời viết trên mạng lại ở lại rất lâu.",
    points: [
      "Gõ xong, đếm chậm đến 3 rồi đọc lại — bạn vẫn muốn gửi không?",
      "Đang giận hoặc quá buồn, hãy tạm giữ tin nhắn đó lại, gửi sau cũng được.",
      "Hỏi 3 câu: Điều này có đúng không? Có tử tế không? Có cần thiết không?",
      "Nếu lỡ gửi điều chưa đúng, hãy xin lỗi thẳng thắn và xóa bài viết.",
    ],
  },
  {
    image: tipsPrivacy,
    alt: "Bạn trẻ ôm điện thoại, được bao quanh bởi lá chắn và ổ khóa che chở ảnh, khóa và thông tin riêng tư",
    title: "Bảo vệ thông tin của bạn",
    hook: "Những điều riêng tư chỉ nên thuộc về bạn — và bạn có quyền giữ chúng.",
    points: [
      "Không chia sẻ mật khẩu hay mã xác thực với bất kỳ ai, kể cả bạn thân.",
      "Đặt tài khoản ở chế độ riêng tư và tắt chia sẻ vị trí.",
      "Không gửi ảnh riêng tư của mình hay của người khác cho bất kỳ ai.",
      "Cẩn thận với người lạ rủ kết bạn, rủ chat riêng hay hứa hẹn điều bất thường.",
    ],
  },
  {
    image: tipsNoshare,
    alt: "Bạn trẻ nhẹ nhàng đóng lại máy tính, tin nhắn không hay tan thành bụi và em hướng về ánh nắng",
    title: "Không lan truyền tin đồn",
    hook: "Mỗi lần chia sẻ là một lần thổi thêm lửa vào câu chuyện.",
    points: [
      "Tin chưa kiểm chứng thì đừng chia sẻ, dù nội dung có hấp dẫn đến đâu.",
      "Không đăng lại ảnh, video hay câu chuyện riêng tư của người khác.",
      "Thấy tin sai sự thật về ai đó, hãy báo cáo thay vì bình luận.",
      "Nếu chính bạn là nạn nhân của tin đồn: lưu bằng chứng và kể cho người lớn bạn tin tưởng.",
    ],
  },
];

type Stage = "intro" | "questions" | "learn" | "reflect" | "done";

const LEARN: { title: string; hook: string; image?: string; points: string[] }[] = [
  {
    title: "Bắt nạt trực tuyến là gì?",
    hook: "Khác gì với một cuộc cãi nhau bình thường?",
    image: learnWhat,
    points: [
      "Là hành vi cố ý dùng mạng xã hội, tin nhắn, trò chơi trực tuyến… để làm tổn thương, hạ nhục hoặc đe dọa người khác.",
      "Thường lặp đi lặp lại và có sự chênh lệch: một người hoặc một nhóm nhắm vào một người.",
      "Khác mâu thuẫn thông thường: mâu thuẫn là hai bên bất đồng ngang nhau; bắt nạt là cố tình làm người kia sợ hãi, xấu hổ.",
      "Nội dung trên mạng lan nhanh, khó xóa và có thể theo nạn nhân cả ngày lẫn đêm.",
    ],
  },
  {
    title: "Các hình thức thường gặp",
    hook: "Bắt nạt không chỉ là những lời chửi bới.",
    image: learnForms,
    points: [
      "Xúc phạm, chế giễu: bình luận ác ý về ngoại hình, gia đình, vùng miền, giới tính.",
      "Tung tin đồn, bịa chuyện, cắt ghép ảnh để bôi nhọ.",
      "Giả mạo tài khoản để đăng nội dung xấu dưới tên người khác.",
      "Cô lập: cố tình loại ai đó khỏi nhóm chat, kêu gọi mọi người tẩy chay.",
      "Quấy rối, nhắn tin liên tục, theo dõi hoạt động trên mạng.",
      "Đe dọa, tống tiền hoặc phát tán hình ảnh, thông tin riêng tư.",
    ],
  },
  {
    title: "Dấu hiệu một người đang bị tổn thương",
    hook: "Để nhận ra sớm và kịp thời giúp đỡ.",
    points: [
      "Lo lắng, giật mình khi có thông báo điện thoại; bỗng nhiên né tránh hoặc dùng mạng quá nhiều.",
      "Thu mình, ít nói, không muốn đến trường hay gặp bạn bè.",
      "Thay đổi giấc ngủ, ăn uống; học tập sa sút.",
      "Xóa tài khoản, giấu điện thoại, không muốn kể chuyện.",
      "Nói những câu như “mình vô dụng”, “biến mất cho xong” — đây là dấu hiệu cần quan tâm ngay.",
    ],
  },
  {
    title: "Khi bạn là người chứng kiến",
    hook: "Một hành động nhỏ có thể thay đổi rất nhiều.",
    image: learnBystander,
    points: [
      "Không thích, không chia sẻ, không bình luận thêm vào nội dung bắt nạt.",
      "Nhắn riêng hỏi thăm người bị bắt nạt: “Mình thấy chuyện đó, bạn ổn không?”.",
      "Báo cáo bài viết hoặc tài khoản lên nền tảng.",
      "Kể với thầy cô, phụ huynh hoặc người lớn đáng tin cậy.",
      "Không nên: công kích lại người bắt nạt, đăng lại bằng chứng công khai hay ép nạn nhân kể chuyện.",
    ],
  },
  {
    title: "Bảo vệ tài khoản và lưu bằng chứng",
    hook: "Những kỹ năng ai cũng nên biết.",
    image: learnProtect,
    points: [
      "Dùng mật khẩu mạnh, bật xác thực hai lớp, không chia sẻ mã OTP.",
      "Để tài khoản riêng tư, giới hạn ai có thể nhắn tin, gắn thẻ bạn.",
      "Chụp màn hình rõ tên tài khoản, ngày giờ; lưu đường link trước khi chặn.",
      "Dùng tính năng chặn và báo cáo; không trả lời hay cãi lại người bắt nạt.",
    ],
  },
  {
    title: "Khi nào cần tìm trợ giúp ngay?",
    hook: "Đừng tự chịu đựng một mình.",
    points: [
      "Bị đe dọa đến an toàn, bị tống tiền hoặc bị phát tán ảnh riêng tư: gọi Công an 113.",
      "Trẻ em và người dưới 18 tuổi: gọi Tổng đài quốc gia bảo vệ trẻ em 111 (miễn phí, 24/7).",
      "Khi cảm thấy quá sức chịu đựng, hãy nói ngay với người lớn đáng tin cậy hoặc người hỗ trợ SafeNet.",
    ],
  },
];


function PrivacyPill() {
  return (
    <span className="flex items-center gap-1.5 rounded-full bg-sage/25 px-3 py-1.5 text-[11px] font-medium text-sage-deep">
      <span className="size-1.5 rounded-full bg-sage-deep" />
      Bí mật
    </span>
  );
}

function PrivacyStrip({ text }: { text: string }) {
  return (
    <div className="flex items-center gap-3 rounded-2xl bg-sage/20 p-4">
      <span className="grid size-10 shrink-0 place-items-center rounded-full bg-sage-deep text-cream">
        <Lock className="size-4" />
      </span>
      <p className="text-[13px] leading-snug text-ink-soft">{text}</p>
    </div>
  );
}

function OptionRow({
  selected,
  label,
  onClick,
}: {
  selected: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={selected}
      className={`flex w-full items-center gap-3 rounded-2xl p-3.5 text-left transition-colors duration-200 ${
        selected
          ? "bg-rose/10 ring-1 ring-rose/40"
          : "bg-cream ring-1 ring-line hover:bg-sand/60"
      }`}
    >
      <span
        className={`grid size-5 shrink-0 place-items-center rounded-full ${
          selected ? "bg-rose" : "ring-1 ring-line"
        }`}
      >
        {selected && <span className="size-2 rounded-full bg-cream" />}
      </span>
      <span className={`text-[14px] ${selected ? "font-medium text-ink" : "text-ink-soft"}`}>
        {label}
      </span>
    </button>
  );
}

function SupportFooter() {
  return (
    <div className="mt-8 text-center">
      <p className="text-[12px] text-ink-soft">Cần nói chuyện với một người thật?</p>
      <div className="mt-2 flex flex-wrap justify-center gap-2">
        {SUPPORTS.map((person) => (
          <a
            key={person.email}
            href={supportMailto(person.email)}
            className="inline-flex items-center gap-1.5 whitespace-nowrap rounded-full bg-card px-3.5 py-2 text-[12px] font-medium text-ink ring-1 ring-line transition-colors hover:bg-sand"
          >
            <Mail className="size-3.5 text-rose-deep" />
            {person.name}
          </a>
        ))}
      </div>
      <p className="mt-2 text-[11px] text-ink-soft">Không phải máy trả lời tự động.</p>
      <Link
        to="/ho-tro"
        className="mt-3 inline-block text-[11px] text-ink-soft/70 underline decoration-line underline-offset-2 transition-colors hover:text-rose-deep"
      >
        Bạn là người hỗ trợ? Vào khu vực đọc thư.
      </Link>
    </div>
  );
}

function SupportCard() {
  return (
    <div className="rounded-[24px] bg-card p-5 ring-1 ring-black/5">
      <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-rose-deep">
        Người hỗ trợ của bạn
      </p>
      <p className="mt-3 text-[12px] leading-relaxed text-ink-soft">
        Nếu bạn muốn kể lại mọi chuyện với một người thật, viết cho một trong hai người dưới đây.
        Không cần viết dài, không cần dùng tên thật — chỉ cần nói ra điều đang khiến bạn nặng lòng.
      </p>
      <div className="mt-4 space-y-3">
        {SUPPORTS.map((person) => (
          <div key={person.email} className="rounded-2xl bg-cream p-4 ring-1 ring-line">
            <div className="flex items-center gap-3">
              <span className="grid size-10 shrink-0 place-items-center rounded-full bg-rose font-display text-base font-bold text-cream">
                {person.initial}
              </span>
              <div>
                <p className="font-display text-[15px] font-semibold leading-snug">{person.name}</p>
                <p className="text-[11px] text-ink-soft">{person.role}</p>
              </div>
            </div>
            <a
              href={supportMailto(person.email)}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-full bg-rose py-3 font-semibold text-[14px] text-cream transition-colors active:bg-rose-deep"
            >
              <Mail className="size-4" />
              Gửi email cho tôi
            </a>
            <p className="mt-2 text-center text-[11px] text-ink-soft">{person.email}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function Index() {
  const [stage, setStage] = useState<Stage>("intro");
  const [qIndex, setQIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string[]>>({});
  const [reflection, setReflection] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [studentName, setStudentName] = useState("");
  const [studentClass, setStudentClass] = useState("");
  const [sealing, setSealing] = useState(false);
  const [sealError, setSealError] = useState(false);
  const [sealed, setSealed] = useState<{ code: string; hasEmail: boolean } | null>(null);

  const question = QUESTIONS[qIndex] as Question;
  const selected = answers[question?.key] ?? [];
  const total = QUESTIONS.length;

  const toggleOption = (optionId: string) => {
    setAnswers((prev) => {
      const current = prev[question.key] ?? [];
      if (question.multi) {
        return {
          ...prev,
          [question.key]: current.includes(optionId)
            ? current.filter((id) => id !== optionId)
            : [...current, optionId],
        };
      }
      return { ...prev, [question.key]: [optionId] };
    });
  };

  const resetAll = () => {
    setStage("intro");
    setQIndex(0);
    setAnswers({});
    setReflection("");
    setContactEmail("");
    setStudentName("");
    setStudentClass("");
    setSealError(false);
    setSealed(null);
    window.scrollTo({ top: 0 });
  };

  const solutions = useMemo(() => {
    const types = answers["type"] ?? [];
    const reason = (answers["reason"] ?? [])[0];
    const list: { icon: React.ReactNode; title: string; body: string; steps: string[] }[] = [
      {
        icon: <Camera className="size-4" />,
        title: "Lưu lại bằng chứng",
        body: "Chụp màn hình tin nhắn, bình luận và đường link. Đừng xóa chúng — bằng chứng sẽ giúp bạn khi báo cáo hoặc cần người lớn hỗ trợ.",
        steps: [
          "Chụp màn hình sao cho thấy rõ tên tài khoản, nội dung và ngày giờ.",
          "Sao chép đường link của bài viết, bình luận hoặc trang cá nhân người bắt nạt.",
          "Lưu tất cả vào một thư mục riêng (hoặc gửi cho người lớn bạn tin tưởng giữ hộ).",
          "Ghi chú ngắn: chuyện xảy ra khi nào, ở đâu, có ai chứng kiến.",
          "Đừng trả lời hay cãi lại — điều đó thường khiến mọi việc tệ hơn.",
        ],
      },
      {
        icon: <Ban className="size-4" />,
        title: "Chặn và báo cáo",
        body: "Hầu hết mạng xã hội và ứng dụng trò chuyện đều có nút Chặn và Báo cáo. Sử dụng chúng ngay khi bị quấy rối, và kiểm tra lại quyền riêng tư của tài khoản.",
        steps: [
          "Facebook/Messenger: vào trang cá nhân người đó → dấu ba chấm → Chặn / Tìm hỗ trợ hoặc báo cáo.",
          "TikTok, Instagram: nhấn giữ bình luận hoặc vào trang cá nhân → Báo cáo → Chặn.",
          "Zalo: mở cuộc trò chuyện → Tùy chọn → Báo xấu, rồi Chặn tin nhắn và cuộc gọi.",
          "Đặt tài khoản ở chế độ riêng tư, giới hạn ai được bình luận và nhắn tin cho bạn.",
          "Đổi mật khẩu và bật xác thực hai lớp nếu nghi ngờ tài khoản bị xâm nhập.",
        ],
      },
      {
        icon: <HeartHandshake className="size-4" />,
        title:
          reason === "bystander"
            ? "Đồng hành với người bạn lo lắng"
            : "Nói với người bạn tin tưởng",
        body:
          reason === "bystander"
            ? "Lắng nghe mà không phán xét, giúp người ấy lưu bằng chứng và cùng nhau tìm một người lớn đáng tin cậy để trao đổi."
            : "Gia đình, thầy cô hoặc một người bạn thân — việc kể ra đã là bước bắt đầu. Bạn không cần đối diện với tất cả một mình.",
        steps:
          reason === "bystander"
            ? [
                "Nhắn riêng hỏi thăm: \"Mình thấy chuyện đó, bạn ổn không?\"",
                "Lắng nghe, đừng trách hay bảo họ \"kệ đi\".",
                "Không chia sẻ lại hay bình luận thêm vào nội dung bắt nạt.",
                "Giúp họ lưu bằng chứng và báo cáo tài khoản vi phạm.",
                "Cùng họ đi gặp thầy cô, phụ huynh hoặc gọi 111 nếu cần.",
              ]
            : [
                "Chọn một người bạn thấy an toàn: bố mẹ, anh chị, thầy cô chủ nhiệm, cô tư vấn tâm lý.",
                "Nếu khó nói trực tiếp, hãy nhắn tin hoặc viết ra giấy rồi đưa cho họ.",
                "Cho họ xem bằng chứng bạn đã lưu.",
                "Nói rõ bạn cần gì: chỉ cần lắng nghe, hay cần giúp báo cáo với nhà trường.",
                "Bạn cũng có thể nhắn cho người hỗ trợ SafeNet bên dưới bất cứ lúc nào.",
              ],
      },
    ];
    if (types.includes("threats") || types.includes("stalking")) {
      list.unshift({
        icon: <ShieldAlert className="size-4" />,
        title: "Khi bạn cảm thấy ngay lúc này không an toàn",
        body: "Nếu có lời đe dọa tính mạng, hoặc ai đó tìm đến bạn ngoài đời, hãy gọi ngay 113 (công an) và cho một người lớn biết ngay lập tức.",
        steps: [
          "Gọi 113 nếu đang gặp nguy hiểm, hoặc 111 (miễn phí, 24/7) để được tư vấn.",
          "Báo ngay cho bố mẹ hoặc một người lớn ở gần bạn.",
          "Tắt chia sẻ vị trí trên mọi ứng dụng, không đăng nơi bạn đang ở.",
          "Không đi gặp người đe dọa bạn, dù họ hứa hẹn điều gì.",
          "Giữ lại toàn bộ tin nhắn đe dọa để trình báo công an.",
        ],
      });
    }
    return list;
  }, [answers]);

  /* ---------------- Intro ---------------- */
  if (stage === "intro") {
    return (
      <div className="min-h-screen bg-cream text-ink">
        <div className="mx-auto flex min-h-screen max-w-md flex-col px-6 pt-6 pb-10">
          <header className="rise flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="grid size-9 place-items-center rounded-full bg-rose font-display text-lg font-bold text-cream">
                H
              </span>
              <span className="font-display text-lg font-semibold tracking-tight">
                Hộp thư SafeNet
              </span>
            </div>
            <PrivacyPill />
          </header>

          <section className="pt-12">
            <p className="rise text-[11px] font-medium uppercase tracking-[0.22em] text-rose-deep">
              Một căn phòng yên tĩnh
            </p>
            <h1 className="rise mt-3 font-display text-[2.6rem] font-bold leading-[1.05] tracking-tight text-balance [animation-delay:80ms]">
              Bạn không
              <br />
              đơn độc ở đây.
            </h1>
            <p className="rise mt-4 max-w-[34ch] text-[15px] leading-relaxed text-pretty text-ink-soft [animation-delay:160ms]">
              Nếu bạn đang gặp chuyện không dễ nói trên mạng — đây là nơi để bạn trút hết ra.
              Không phán xét, không vội vàng, và không ai biết bạn là ai.
            </p>
          </section>

          <div className="rise mt-8 rounded-[24px] bg-card p-4 ring-1 ring-black/5 [animation-delay:200ms]">
            <p className="text-[12px] font-medium text-ink-soft">Họ tên và lớp (không bắt buộc)</p>
            <div className="mt-2 grid grid-cols-[1fr_6.5rem] gap-2">
              <input
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                maxLength={80}
                placeholder="Họ và tên"
                aria-label="Họ và tên (trang đầu)"
                className="w-full rounded-2xl bg-cream p-3.5 text-[14px] text-ink ring-1 ring-line outline-none placeholder:text-ink-soft/60 focus:ring-2 focus:ring-rose"
              />
              <input
                value={studentClass}
                onChange={(e) => setStudentClass(e.target.value)}
                maxLength={20}
                placeholder="Lớp"
                aria-label="Lớp (trang đầu)"
                className="w-full rounded-2xl bg-cream p-3.5 text-[14px] text-ink ring-1 ring-line outline-none placeholder:text-ink-soft/60 focus:ring-2 focus:ring-rose"
              />
            </div>
            <p className="mt-1.5 text-[11px] leading-relaxed text-ink-soft">
              Chỉ hai người hỗ trợ của SafeNet nhìn thấy — không ai khác biết bạn là ai.
            </p>
          </div>

          <div className="rise mt-6 [animation-delay:240ms]">
            <button
              type="button"
              onClick={() => setStage("questions")}
              className="w-full rounded-full bg-rose py-4 font-display text-[16px] font-semibold text-cream shadow-[0_14px_30px_-14px_var(--rose-deep)] transition-colors active:bg-rose-deep"
            >
              Bắt đầu trò chuyện
            </button>
            <p className="mt-3 text-center text-[12px] text-ink-soft">
              Vài câu hỏi nhỏ — trả lời theo cách của bạn.
            </p>
          </div>

          <p className="rise mt-4 text-center text-[12px] leading-relaxed text-ink-soft [animation-delay:300ms]">
            Hoặc viết trực tiếp cho{" "}
            {SUPPORTS.map((person, i) => (
              <span key={person.email}>
                {i > 0 && " hoặc "}
                <a
                  href={supportMailto(person.email)}
                  className="font-medium whitespace-nowrap text-rose-deep underline underline-offset-2"
                >
                  {person.name}
                </a>
              </span>
            ))}
            , người hỗ trợ của SafeNet.
          </p>

          <p className="rise mt-2 text-center text-[12px] [animation-delay:310ms]">
            Đã gửi thư rồi?{" "}
            <Link
              to="/doc-thu"
              className="font-medium text-rose-deep underline underline-offset-2"
            >
              Đọc thư trả lời của bạn
            </Link>
          </p>

          <div className="rise mt-auto pt-10 [animation-delay:320ms]">
            <PrivacyStrip text="Mọi điều bạn chia sẻ đều được bảo mật. Chúng tôi không lưu tên, không lưu vết, và không chia sẻ với bất kỳ ai." />
            <div className="mt-4 rounded-2xl bg-sand p-4">
              <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-sage-deep">
                Sau khi bạn gửi
              </p>
              <div className="mt-3 space-y-2.5">
                {[
                  {
                    title: "Hướng dẫn từng bước để an toàn",
                    points: [
                      "Không trả lời hay cãi lại người bắt nạt — im lặng khiến họ mất hứng.",
                      "Đặt tài khoản ở chế độ riêng tư, giới hạn ai được nhắn tin và bình luận.",
                      "Đổi mật khẩu, bật xác thực hai lớp, tắt chia sẻ vị trí.",
                      "Tạm rời mạng xã hội một thời gian nếu bạn thấy quá mệt mỏi.",
                      "Nếu bị đe dọa tính mạng, gọi ngay 113 và báo cho người lớn.",
                    ],
                  },
                  {
                    title: "Cách lưu bằng chứng và báo cáo",
                    points: [
                      "Chụp màn hình thấy rõ tên tài khoản, nội dung và ngày giờ.",
                      "Sao chép đường link bài viết, bình luận, trang cá nhân.",
                      "Dùng nút Báo cáo trên Facebook, TikTok, Instagram, Zalo… rồi Chặn.",
                      "Đưa bằng chứng cho thầy cô, phụ huynh để báo với nhà trường.",
                      "Với đe dọa, tống tiền hay phát tán hình ảnh riêng tư — trình báo công an.",
                    ],
                  },
                  {
                    title: "Nơi nhận hỗ trợ chuyên môn",
                    points: [
                      "Tổng đài Quốc gia Bảo vệ Trẻ em 111 — miễn phí, 24/7.",
                      "Công an 113 khi đang gặp nguy hiểm.",
                      "Phòng tư vấn tâm lý học đường hoặc thầy cô chủ nhiệm.",
                      "Người hỗ trợ SafeNet — viết thư ẩn danh ngay trên trang này và nhận trả lời bằng mã bí mật.",
                    ],
                  },
                ].map((item, i) => (
                  <details
                    key={item.title}
                    className="group rounded-2xl bg-card p-3.5 ring-1 ring-black/5 open:ring-rose/40"
                  >
                    <summary className="flex cursor-pointer list-none items-center gap-3 [&::-webkit-details-marker]:hidden">
                      <span className="grid size-8 shrink-0 place-items-center rounded-full bg-rose/15 font-display text-sm font-bold text-rose-deep">
                        {i + 1}
                      </span>
                      <span className="flex-1 text-[13px] font-medium">{item.title}</span>
                      <span className="text-[16px] text-rose-deep transition-transform group-open:rotate-90">
                        ›
                      </span>
                    </summary>
                    <ul className="mt-3 space-y-2 border-t border-line pt-3 pl-11">
                      {item.points.map((p) => (
                        <li key={p} className="list-disc text-[13px] leading-relaxed text-ink marker:text-rose-deep">
                          {p}
                        </li>
                      ))}
                    </ul>
                  </details>
                ))}
              </div>
            </div>
          </div>

          <section className="rise mt-6 [animation-delay:340ms]">
            <div className="rounded-[24px] bg-sand p-4">
              <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-rose-deep">
                Kỹ năng ứng xử trên mạng
              </p>
              <h2 className="mt-1.5 font-display text-[1.25rem] font-semibold leading-snug tracking-tight">
                Bốn bài học nhỏ cho mỗi ngày
              </h2>
              <p className="mt-1 text-[12px] leading-relaxed text-ink-soft">
                Bấm vào từng tranh để xem gợi ý — áp dụng được ngay hôm nay.
              </p>
              <div className="mt-3 space-y-2.5">
                {TIPS.map((tip) => (
                  <details
                    key={tip.title}
                    className="group overflow-hidden rounded-2xl bg-card ring-1 ring-black/5 open:ring-rose/40"
                  >
                    <summary className="cursor-pointer list-none [&::-webkit-details-marker]:hidden">
                      <div className="relative">
                        <img
                          src={tip.image}
                          alt={tip.alt}
                          width={960}
                          height={640}
                          loading="lazy"
                          className="aspect-[3/2] w-full object-cover"
                        />
                        <span className="absolute right-2.5 top-2.5 grid size-7 place-items-center rounded-full bg-card/90 text-rose-deep transition-transform group-open:rotate-90">
                          ›
                        </span>
                      </div>
                      <div className="p-3.5">
                        <p className="text-[14px] font-medium">{tip.title}</p>
                        <p className="mt-0.5 text-[12px] leading-relaxed text-ink-soft">{tip.hook}</p>
                        <p className="mt-1.5 text-[12px] font-medium text-rose-deep">
                          <span className="group-open:hidden">Xem gợi ý ›</span>
                          <span className="hidden group-open:inline">Thu gọn ˄</span>
                        </p>
                      </div>
                    </summary>
                    <ul className="space-y-2 border-t border-line px-3.5 py-3 pl-7">
                      {tip.points.map((p) => (
                        <li
                          key={p}
                          className="list-disc text-[13px] leading-relaxed text-ink marker:text-rose-deep"
                        >
                          {p}
                        </li>
                      ))}
                    </ul>
                  </details>
                ))}
              </div>
            </div>
          </section>

          <SupportFooter />
        </div>
      </div>
    );
  }

  /* ---------------- Learn ---------------- */
  if (stage === "learn") {
    return (
      <div className="min-h-screen bg-cream text-ink">
        <div className="mx-auto flex min-h-screen max-w-md flex-col px-6 pt-6 pb-10">
          <header className="rise flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="grid size-9 place-items-center rounded-full bg-rose font-display text-lg font-bold text-cream">
                H
              </span>
              <span className="font-display text-lg font-semibold tracking-tight">
                Hộp thư SafeNet
              </span>
            </div>
            <PrivacyPill />
          </header>

          <section className="rise mt-8">
            <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-rose-deep">
              Góc tìm hiểu
            </p>
            <h1 className="mt-2 font-display text-[1.9rem] font-semibold leading-tight tracking-tight text-balance">
              Hiểu về bắt nạt trực tuyến
            </h1>
            <p className="mt-2 text-[14px] leading-relaxed text-ink-soft">
              Hiểu đúng là bước đầu để bảo vệ chính mình và những người xung quanh. Bấm vào từng mục để đọc.
            </p>
          </section>

          <div className="rise mt-6 space-y-2.5">
            {LEARN.map((item, i) => (
              <details
                key={item.title}
                className="group overflow-hidden rounded-2xl bg-card ring-1 ring-black/5 open:ring-rose/40"
              >
                <summary className="cursor-pointer list-none [&::-webkit-details-marker]:hidden">
                  {item.image && (
                    <img
                      src={item.image}
                      alt=""
                      width={960}
                      height={640}
                      loading="lazy"
                      className="aspect-[3/1] w-full object-cover"
                    />
                  )}
                  <div className="flex items-start gap-3 p-4">
                    <span className="grid size-7 shrink-0 place-items-center rounded-full bg-rose/15 text-[13px] font-semibold text-rose-deep">
                      {i + 1}
                    </span>
                    <div className="flex-1">
                      <p className="text-[15px] font-medium leading-snug">{item.title}</p>
                      <p className="mt-0.5 text-[12px] leading-relaxed text-ink-soft">{item.hook}</p>
                    </div>
                    <span className="text-rose-deep transition-transform group-open:rotate-90">›</span>
                  </div>
                </summary>
                <ul className="space-y-2 border-t border-line px-4 py-3 pl-8">
                  {item.points.map((p) => (
                    <li
                      key={p}
                      className="list-disc text-[13px] leading-relaxed marker:text-rose-deep"
                    >
                      {p}
                    </li>
                  ))}
                </ul>
              </details>
            ))}
          </div>

          <div className="rise mt-6 rounded-[24px] bg-sand p-5">
            <p className="font-display text-[1.1rem] font-semibold">Bạn hoặc ai đó cần giúp đỡ?</p>
            <p className="mt-1 text-[13px] leading-relaxed text-ink-soft">
              Bạn có thể chia sẻ câu chuyện và gửi thư ẩn danh cho người hỗ trợ bất cứ lúc nào.
            </p>
            <button
              type="button"
              onClick={() => {
                setAnswers({});
                setQIndex(0);
                setStage("questions");
                window.scrollTo({ top: 0 });
              }}
              className="mt-4 w-full rounded-full bg-rose py-3.5 text-[15px] font-semibold text-cream active:bg-rose-deep"
            >
              Tôi cần được hỗ trợ
            </button>
            <button
              type="button"
              onClick={() => {
                resetAll();
                window.scrollTo({ top: 0 });
              }}
              className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-full py-3 text-[14px] font-medium text-ink-soft ring-1 ring-line"
            >
              <ArrowLeft className="size-4" />
              Về trang đầu
            </button>
          </div>

          <SupportFooter />
        </div>
      </div>
    );
  }

  /* ---------------- Questions ---------------- */
  if (stage === "questions") {
    return (
      <div className="min-h-screen bg-cream text-ink">
        <div className="mx-auto flex min-h-screen max-w-md flex-col px-6 pt-6 pb-10">
          <header className="rise flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="grid size-9 place-items-center rounded-full bg-rose font-display text-lg font-bold text-cream">
                H
              </span>
              <span className="font-display text-lg font-semibold tracking-tight">
                Hộp thư SafeNet
              </span>
            </div>
            <PrivacyPill />
          </header>

          <div className="rise mt-8" key={question.key}>
            <div className="flex items-center justify-between text-[11px] font-medium text-ink-soft">
              <span>{question.eyebrow}</span>
              <span className="text-rose-deep">Bước {qIndex + 1}</span>
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-sand">
              <div
                className="h-full rounded-full bg-rose transition-all duration-500"
                style={{ width: `${((qIndex + 1) / total) * 100}%` }}
              />
            </div>
          </div>

          <section className="rise mt-6" key={`card-${question.key}`}>
            <div className="rounded-[28px] bg-card p-6 ring-1 ring-black/5">
              <p className="font-display text-[1.5rem] font-semibold leading-snug tracking-tight text-balance">
                {question.title}
              </p>
              <p className="mt-2 text-[13px] leading-relaxed text-ink-soft">{question.subtitle}</p>

              <div className="mt-5 space-y-2.5">
                {question.options.map((option) => (
                  <OptionRow
                    key={option.id}
                    label={option.label}
                    selected={selected.includes(option.id)}
                    onClick={() => toggleOption(option.id)}
                  />
                ))}
              </div>

              <div className="mt-6 flex gap-3">
                {qIndex > 0 ? (
                  <button
                    type="button"
                    onClick={() => setQIndex((i) => i - 1)}
                    className="flex items-center gap-1.5 rounded-full px-5 py-3.5 text-[14px] font-medium text-ink-soft ring-1 ring-line transition-colors hover:bg-sand"
                  >
                    <ArrowLeft className="size-4" />
                    Quay lại
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setStage("intro")}
                    className="flex items-center gap-1.5 rounded-full px-5 py-3.5 text-[14px] font-medium text-ink-soft ring-1 ring-line transition-colors hover:bg-sand"
                  >
                    <ArrowLeft className="size-4" />
                    Trang đầu
                  </button>
                )}
                <button
                  type="button"
                  disabled={selected.length === 0}
                  onClick={() => {
                    if (qIndex === 0 && selected[0] === "learn") {
                      setStage("learn");
                    } else if (qIndex + 1 < total) {
                      setQIndex((i) => i + 1);
                    } else {
                      setStage("reflect");
                    }
                    window.scrollTo({ top: 0 });
                  }}
                  className="flex-1 rounded-full bg-rose py-3.5 font-semibold text-[15px] text-cream transition-colors active:bg-rose-deep disabled:cursor-not-allowed disabled:opacity-40"
                >
                  {qIndex + 1 < total ? "Tiếp tục" : "Đến bước cuối"}
                </button>
              </div>
            </div>
          </section>

          <div className="mt-auto pt-8">
            <PrivacyStrip text="Chúng tôi không hỏi tên, tuổi hay địa chỉ của bạn. Những câu này chỉ giúp chúng tôi đưa ra lời khuyên phù hợp hơn." />
          </div>

          <SupportFooter />
        </div>
      </div>
    );
  }

  /* ---------------- Reflection ---------------- */
  if (stage === "reflect") {
    return (
      <div className="min-h-screen bg-cream text-ink">
        <div className="mx-auto flex min-h-screen max-w-md flex-col px-6 pt-6 pb-10">
          <header className="rise flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="grid size-9 place-items-center rounded-full bg-rose font-display text-lg font-bold text-cream">
                H
              </span>
              <span className="font-display text-lg font-semibold tracking-tight">
                Hộp thư SafeNet
              </span>
            </div>
            <PrivacyPill />
          </header>

          <div className="rise mt-8">
            <div className="flex items-center justify-between text-[11px] font-medium text-ink-soft">
              <span>Bước cuối</span>
              <span className="text-rose-deep">Thư của bạn</span>
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-sand">
              <div className="h-full w-full rounded-full bg-rose transition-all duration-500" />
            </div>
          </div>

          <section className="rise mt-6">
            <div className="rounded-[28px] bg-card p-6 ring-1 ring-black/5">
              <span className="grid size-11 place-items-center rounded-2xl bg-rose/15 text-rose-deep">
                <PenLine className="size-5" />
              </span>
              <p className="mt-4 font-display text-[1.5rem] font-semibold leading-snug tracking-tight text-balance">
                Bạn đang cảm nhận như thế nào?
              </p>
              <p className="mt-2 text-[13px] leading-relaxed text-ink-soft">
                Hãy viết cảm nhận của bạn ra đây — chuyện gì đã xảy ra, điều gì khiến bạn nặng lòng,
                hay bất cứ điều gì bạn muốn nói. Viết ngắn hoặc dài đều được, và không bắt buộc.
              </p>

              <textarea
                value={reflection}
                onChange={(e) => setReflection(e.target.value)}
                maxLength={1500}
                rows={7}
                placeholder="Tôi cảm thấy…"
                className="mt-5 w-full resize-none rounded-2xl bg-cream p-4 text-[14px] leading-relaxed text-ink ring-1 ring-line outline-none transition-shadow placeholder:text-ink-soft/60 focus:ring-2 focus:ring-rose"
              />
              <p className="mt-1.5 text-right text-[11px] text-ink-soft">
                {reflection.length}/1500
              </p>

              <div className="mt-5 border-t border-line pt-5">
                <p className="text-[12px] font-medium text-ink-soft">
                  Họ tên và lớp (không bắt buộc)
                </p>
                <div className="mt-2 grid grid-cols-[1fr_6.5rem] gap-2">
                  <input
                    value={studentName}
                    onChange={(e) => setStudentName(e.target.value)}
                    maxLength={80}
                    placeholder="Họ và tên"
                    aria-label="Họ và tên"
                    className="w-full rounded-2xl bg-cream p-4 text-[14px] text-ink ring-1 ring-line outline-none placeholder:text-ink-soft/60 focus:ring-2 focus:ring-rose"
                  />
                  <input
                    value={studentClass}
                    onChange={(e) => setStudentClass(e.target.value)}
                    maxLength={20}
                    placeholder="Lớp"
                    aria-label="Lớp"
                    className="w-full rounded-2xl bg-cream p-4 text-[14px] text-ink ring-1 ring-line outline-none placeholder:text-ink-soft/60 focus:ring-2 focus:ring-rose"
                  />
                </div>
                <p className="mt-1.5 text-[11px] leading-relaxed text-ink-soft">
                  Chỉ hai người hỗ trợ của SafeNet nhìn thấy để giúp bạn kịp thời. Không hiện ở trang
                  đọc thư, kể cả khi ai đó biết mã của bạn.
                </p>
              </div>

              <div className="mt-5 border-t border-line pt-5">
                <label htmlFor="contact-email" className="text-[12px] font-medium text-ink-soft">
                  Email nhận thư trả lời (không bắt buộc)
                </label>
                <input
                  id="contact-email"
                  type="email"
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                  placeholder="ban@email.com"
                  className="mt-2 w-full rounded-2xl bg-cream p-4 text-[14px] text-ink ring-1 ring-line outline-none transition-shadow placeholder:text-ink-soft/60 focus:ring-2 focus:ring-rose"
                />
                <p className="mt-1.5 text-[11px] leading-relaxed text-ink-soft">
                  Nếu để lại, thư trả lời sẽ được gửi thẳng tới email của bạn. Bỏ trống thì vẫn nhận
                  được trả lời qua mã bí mật.
                </p>
              </div>
            </div>
          </section>

          <div className="rise mt-5">
            <PrivacyStrip text="Lá thư được niêm phong cùng một mã bí mật chỉ bạn biết. Tên, lớp và email (nếu bạn để lại) chỉ người hỗ trợ xem được, không ai khác." />
          </div>

          <div className="mt-5 flex gap-3">
            <button
              type="button"
              onClick={() => setStage("questions")}
              className="flex items-center gap-1.5 rounded-full px-5 py-3.5 text-[14px] font-medium text-ink-soft ring-1 ring-line transition-colors hover:bg-sand"
            >
              <ArrowLeft className="size-4" />
              Quay lại
            </button>
            <button
              type="button"
              disabled={sealing}
              onClick={async () => {
                setSealing(true);
                setSealError(false);
                const result = await sealLetter({
                  data: {
                    answers,
                    message: reflection,
                    contactEmail: contactEmail.trim() || null,
                    studentName: studentName.trim() || null,
                    studentClass: studentClass.trim() || null,
                  },
                });
                setSealing(false);
                if (!result.ok) {
                  setSealError(true);
                  return;
                }
                setSealed({ code: result.code, hasEmail: result.hasEmail });
                setStage("done");
                window.scrollTo({ top: 0 });
              }}
              className="flex-1 rounded-full bg-rose py-3.5 font-semibold text-[15px] text-cream transition-colors active:bg-rose-deep disabled:opacity-40"
            >
              {sealing ? "Đang niêm phong…" : "Niêm phong và gửi đi"}
            </button>
          </div>

          {sealError && (
            <p className="mt-3 text-center text-[12px] text-rose-deep">
              Chưa niêm phong được — kiểm tra kết nối và thử lại nhé.
            </p>
          )}

          <p className="mt-3 text-center text-[12px] text-ink-soft">
            Thư gửi đi rồi vẫn có thể viết lại bất cứ lúc nào bạn muốn.
          </p>

          <SupportFooter />
        </div>
      </div>
    );
  }

  /* ---------------- Done ---------------- */
  return (
    <div className="min-h-screen bg-cream text-ink">
      <div className="mx-auto max-w-md px-6 pt-6 pb-12">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="grid size-9 place-items-center rounded-full bg-rose font-display text-lg font-bold text-cream">
              H
            </span>
            <span className="font-display text-lg font-semibold tracking-tight">
              Hộp thư SafeNet
            </span>
          </div>
          <PrivacyPill />
        </header>

        <section className="mt-10 text-center">
          <span className="seal-pop mx-auto grid size-16 place-items-center rounded-full bg-sage-deep text-cream shadow-[0_16px_34px_-16px_var(--sage-deep)]">
            <Lock className="size-6" />
          </span>
          <h1 className="rise mt-5 font-display text-[2rem] font-bold leading-tight tracking-tight text-balance [animation-delay:120ms]">
            Thư của bạn đã được niêm phong
          </h1>
          <p className="rise mx-auto mt-3 max-w-[36ch] text-[14px] leading-relaxed text-pretty text-ink-soft [animation-delay:200ms]">
            Cảm ơn bạn đã tin tưởng chia sẻ. Việc bạn lên tiếng hôm nay — dù chỉ vài dòng — đã là
            một hành động dũng cảm.
          </p>
        </section>

        {sealed && (
          <div className="rise mt-7 rounded-[24px] bg-card p-5 ring-1 ring-black/5 [animation-delay:260ms]">
            <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-rose-deep">
              Mã thư của bạn
            </p>
            <p className="mt-2 font-mono text-[1.7rem] font-bold tracking-[0.18em] text-ink">
              {sealed.code}
            </p>
            <p className="mt-2 text-[12px] leading-relaxed text-ink-soft">
              Ghi nhớ hoặc chụp lại mã này — đó là chìa khóa duy nhất mở lá thư. Khi người hỗ trợ đã
              trả lời, chọn "Đọc thư trả lời" bên dưới và nhập mã để xem.
            </p>
          </div>
        )}

        <div className="rise mt-6 [animation-delay:300ms]">
          <PrivacyStrip text="Không tên, không lưu vết. Lá thư được giữ cùng một mã bí mật — chỉ bạn có mã này. Email bạn để lại (nếu có) chỉ dùng để nhận thư trả lời." />
        </div>

        <section className="rise mt-8 [animation-delay:340ms]">
          <h2 className="font-display text-[1.35rem] font-semibold tracking-tight">
            Giải pháp hỗ trợ dành cho bạn
          </h2>
          <p className="mt-1.5 text-[13px] text-ink-soft">
            Dựa trên điều bạn vừa chia sẻ, đây là những việc bạn có thể làm ngay:
          </p>
          <div className="mt-4 space-y-2.5">
            {solutions.map((solution) => (
              <details
                key={solution.title}
                className="group rounded-2xl bg-card p-4 ring-1 ring-black/5 open:ring-rose/40"
              >
                <summary className="flex cursor-pointer list-none gap-3 [&::-webkit-details-marker]:hidden">
                  <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-rose/15 text-rose-deep">
                    {solution.icon}
                  </span>
                  <div className="flex-1">
                    <p className="text-[14px] font-medium">{solution.title}</p>
                    <p className="mt-0.5 text-[12px] leading-relaxed text-ink-soft">
                      {solution.body}
                    </p>
                    <p className="mt-1.5 text-[12px] font-medium text-rose-deep">
                      <span className="group-open:hidden">Xem chi tiết từng bước ›</span>
                      <span className="hidden group-open:inline">Thu gọn ˄</span>
                    </p>
                  </div>
                </summary>
                <ol className="mt-3 space-y-2 border-t border-line pt-3 pl-12">
                  {solution.steps.map((s, i) => (
                    <li key={i} className="flex gap-2 text-[13px] leading-relaxed text-ink">
                      <span className="grid size-5 shrink-0 place-items-center rounded-full bg-sage/30 text-[11px] font-semibold text-sage-deep">
                        {i + 1}
                      </span>
                      <span>{s}</span>
                    </li>
                  ))}
                </ol>
              </details>
            ))}
          </div>
        </section>

        <section className="rise mt-6 [animation-delay:400ms]">
          <SupportCard />
        </section>

        <section className="rise mt-6 [animation-delay:460ms]">
          <div className="rounded-[24px] bg-sand p-5">
            <div className="flex items-center gap-3">
              <span className="grid size-10 shrink-0 place-items-center rounded-full bg-rose-deep text-cream">
                <Phone className="size-4" />
              </span>
              <div>
                <p className="font-display text-[16px] font-semibold">
                  Tổng đài Quốc gia Bảo vệ Trẻ em — 111
                </p>
                <p className="text-[12px] text-ink-soft">Miễn phí, hoạt động 24/7.</p>
              </div>
            </div>
            <p className="mt-3 text-[12px] leading-relaxed text-ink-soft">
              Nếu bạn chưa 18 tuổi, gọi 111 để được chuyên viên tư vấn ngay. Nếu bạn đã lớn tuổi,
              hãy đến cơ sở y tế hoặc chuyên gia tâm lý gần nhất — và nhớ rằng tìm giúp đỡ chưa bao
              giờ là điều đáng xấu hổ.
            </p>
          </div>
        </section>

        <section className="rise mt-6 [animation-delay:520ms]">
          <div className="rounded-2xl bg-sage/20 p-4">
            <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-sage-deep">
              Một điều nhỏ muốn nhắn với bạn
            </p>
            <p className="mt-2 font-display text-[15px] italic leading-snug text-ink/80">
              “Bắt nạt trực tuyến không phải lỗi của bạn. Bạn xứng đáng được an toàn, trên mạng và
              ngoài đời.”
            </p>
          </div>
        </section>

        <div className="rise mt-8 space-y-3 [animation-delay:580ms]">
          <Link
            to="/doc-thu"
            className="flex w-full items-center justify-center gap-2 rounded-full bg-rose py-4 font-display text-[16px] font-semibold text-cream shadow-[0_14px_30px_-14px_var(--rose-deep)] transition-colors active:bg-rose-deep"
          >
            <MailOpen className="size-4" />
            Đọc thư trả lời
          </Link>
          <button
            type="button"
            onClick={resetAll}
            className="flex w-full items-center justify-center gap-2 rounded-full py-3.5 text-[14px] font-medium text-ink-soft ring-1 ring-line transition-colors hover:bg-sand"
          >
            <RotateCcw className="size-4" />
            Viết một lá thư mới
          </button>
        </div>

        <SupportFooter />
      </div>
    </div>
  );
}
