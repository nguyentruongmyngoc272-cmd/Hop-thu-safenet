import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, KeyRound, MailOpen, PenLine, Search, Send } from "lucide-react";
import { lookupLetter, sendWriterMessage, type ThreadMessage } from "@/lib/letters.functions";

function fmt(iso: string) {
  return new Date(iso).toLocaleString("vi-VN", { day: "numeric", month: "numeric", hour: "2-digit", minute: "2-digit" });
}

function Conversation({ code, thread, onSent }: { code: string; thread: ThreadMessage[]; onSent: () => Promise<void> }) {
  const send = useServerFn(sendWriterMessage);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(false);
  const last = thread[thread.length - 1];

  async function submit() {
    if (!draft.trim() || sending) return;
    setSending(true);
    setError(false);
    const res = await send({ data: { code, body: draft.trim() } });
    setSending(false);
    if (!res.ok) return setError(true);
    setDraft("");
    await onSent();
  }

  return (
    <div className="rounded-[24px] bg-card p-4 ring-1 ring-black/5">
      <p className="px-1 text-[11px] font-medium uppercase tracking-[0.2em] text-ink-soft">Cuộc trò chuyện · {code}</p>
      <div className="mt-3 space-y-2.5">
        {thread.map((m, i) => (
          <div key={i} className={m.sender === "writer" ? "flex justify-end" : "flex justify-start"}>
            <div className={"max-w-[85%] rounded-2xl px-3.5 py-2.5 " + (m.sender === "writer" ? "rounded-br-md bg-rose text-cream" : "rounded-bl-md bg-sand text-ink")}>
              <p className="text-[10px] font-medium opacity-75">{m.sender === "writer" ? "Bạn" : "Người hỗ trợ"} · {fmt(m.at)}</p>
              <p className="mt-0.5 whitespace-pre-wrap text-[14px] leading-relaxed">{m.body || "(Chỉ trả lời các câu hỏi)"}</p>
            </div>
          </div>
        ))}
      </div>
      {last?.sender === "writer" && (
        <p className="mt-3 text-center text-[11px] text-ink-soft">Người hỗ trợ sẽ trả lời sớm — quay lại bằng mã này nhé.</p>
      )}
      <div className="mt-3 flex items-end gap-2">
        <textarea value={draft} onChange={(e) => setDraft(e.target.value)} maxLength={1500} rows={2} placeholder="Viết tiếp cho người hỗ trợ…" className="w-full resize-none rounded-2xl bg-cream p-3 text-[14px] text-ink ring-1 ring-line outline-none focus:ring-2 focus:ring-rose" />
        <button type="button" onClick={submit} disabled={sending || !draft.trim()} aria-label="Gửi" className="grid size-11 shrink-0 place-items-center rounded-full bg-rose text-cream disabled:opacity-40">
          <Send className="size-4" />
        </button>
      </div>
      {error && <p className="mt-1.5 text-[12px] text-rose-deep">Chưa gửi được — thử lại nhé.</p>}
    </div>
  );
}

export const Route = createFileRoute("/doc-thu")({
  head: () => ({
    meta: [
      { title: "Đọc thư trả lời — Hộp thư SafeNet" },
      {
        name: "description",
        content:
          "Nhập mã bí mật của lá thư để xem thư trả lời từ người hỗ trợ của Hộp thư SafeNet.",
      },
      { property: "og:title", content: "Đọc thư trả lời — Hộp thư SafeNet" },
      {
        property: "og:description",
        content: "Nhập mã bí mật của bạn để đọc thư trả lời từ người hỗ trợ.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ReadReply,
});

type LookupResult = Awaited<ReturnType<typeof lookupLetter>>;

function ReadReply() {
  const lookup = useServerFn(lookupLetter);
  const [code, setCode] = useState("");
  const [result, setResult] = useState<LookupResult | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!code.trim() || loading) return;
    setLoading(true);
    try {
      const res = await lookup({ data: { code } });
      setResult(res);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-cream text-ink">
      <div className="mx-auto flex min-h-screen max-w-md flex-col px-6 pt-6 pb-10">
        <header className="rise flex items-center justify-between">
          <Link to="/" className="flex items-center gap-1.5 text-[13px] font-medium text-ink-soft">
            <ArrowLeft className="size-4" />
            Về trang chính
          </Link>
          <span className="flex items-center gap-1.5 rounded-full bg-sage/25 px-3 py-1.5 text-[11px] font-medium text-sage-deep">
            <span className="size-1.5 rounded-full bg-sage-deep" />
            Bí mật
          </span>
        </header>

        <section className="rise mt-10 text-center">
          <span className="mx-auto grid size-16 place-items-center rounded-full bg-rose/15 text-rose-deep">
            <MailOpen className="size-7" />
          </span>
          <h1 className="mt-5 font-display text-[2rem] font-bold leading-tight tracking-tight text-balance">
            Đọc thư trả lời
          </h1>
          <p className="mx-auto mt-3 max-w-[36ch] text-[14px] leading-relaxed text-pretty text-ink-soft">
            Nhập mã bí mật bạn nhận được khi niêm phong thư. Người hỗ trợ sẽ trả lời bằng chính mã
            này — không ai khác có thể đọc thư của bạn.
          </p>
        </section>

        <form onSubmit={onSubmit} className="rise mt-8">
          <div className="rounded-[28px] bg-card p-6 ring-1 ring-black/5">
            <label htmlFor="letter-code" className="text-[12px] font-medium text-ink-soft">
              Mã bí mật của bạn
            </label>
            <div className="mt-2 flex items-center gap-2 rounded-2xl bg-cream p-1.5 pl-4 ring-1 ring-line focus-within:ring-2 focus-within:ring-rose">
              <KeyRound className="size-4 shrink-0 text-rose-deep" />
              <input
                id="letter-code"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="SN-ABC123"
                autoCapitalize="characters"
                autoComplete="off"
                className="w-full bg-transparent py-3 font-mono text-[16px] uppercase tracking-[0.15em] text-ink outline-none placeholder:text-ink-soft/50"
              />
            </div>
            <button
              type="submit"
              disabled={loading || !code.trim()}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-rose py-3.5 font-semibold text-[15px] text-cream transition-colors active:bg-rose-deep disabled:cursor-not-allowed disabled:opacity-40"
            >
              <Search className="size-4" />
              {loading ? "Đang tìm thư…" : "Mở thư của tôi"}
            </button>
          </div>
        </form>

        {result && !result.found && (
          <div className="rise mt-5 rounded-2xl bg-sand p-4 text-center">
            <p className="text-[13px] font-medium text-ink">Không tìm thấy lá thư nào với mã này.</p>
            <p className="mt-1 text-[12px] leading-relaxed text-ink-soft">
              Kiểm tra lại mã — ví dụ SN-ABC123. Nếu bạn vẫn nhớ nội dung thư đã gửi, bạn có thể viết
              một lá thư mới và giữ mã mới này cẩn thận hơn.
            </p>
          </div>
        )}

        {result?.found && (
          <section className="rise mt-6 space-y-4">
            <Conversation code={result.code} thread={result.thread} onSent={async () => setResult(await lookup({ data: { code } }))} />

            <div className="rounded-2xl bg-sage/20 p-4">
              <p className="text-[13px] italic leading-snug text-ink/80">
                Nếu đang cần nói chuyện ngay, tổng đài Quốc gia Bảo vệ Trẻ em 111 luôn miễn phí và
                hoạt động 24/7.
              </p>
            </div>

            <Link
              to="/"
              className="flex w-full items-center justify-center gap-2 rounded-full py-3.5 text-[14px] font-medium text-ink-soft ring-1 ring-line transition-colors hover:bg-sand"
            >
              <PenLine className="size-4" />
              Viết một lá thư mới
            </Link>
          </section>
        )}
      </div>
    </div>
  );
}
