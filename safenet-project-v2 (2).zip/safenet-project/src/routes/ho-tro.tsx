import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Lock, LockOpen, Mail, Send, Trash2 } from "lucide-react";
import {
  getSupportState,
  listLetters,
  lockSupport,
  replyToLetter,
  deleteLetter,
  unlockSupport,
} from "@/lib/letters.functions";
import { optionLabel } from "@/lib/questions";

const TOKEN_KEY = "safenet-support-token";
function getToken(): string | null {
  try {
    return sessionStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export const Route = createFileRoute("/ho-tro")({
  head: () => ({
    meta: [
      { title: "Khu vực người hỗ trợ — Hộp thư SafeNet" },
      { name: "robots", content: "noindex" },
    ],
  }),
  ssr: false,
  loader: async () => {
    const token = getToken();
    const state = await getSupportState({ data: { token } });
    if (!state.unlocked) return { unlocked: false as const, letters: [] };
    const letters = await listLetters({ data: { token } });
    return { unlocked: true as const, letters };
  },
  component: SupportArea,
});

type Letters = Awaited<ReturnType<typeof listLetters>>;
type LetterRow = Letters[number];

function formatDate(iso: string | null): string {
  if (!iso) return "";
  return new Date(iso).toLocaleString("vi-VN", {
    day: "numeric",
    month: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function AnswerChips({ answers }: { answers: unknown }) {
  const map = (answers ?? {}) as Record<string, string[]>;
  const labels: string[] = [];
  for (const [key, ids] of Object.entries(map)) {
    for (const id of ids) labels.push(optionLabel(key, id));
  }
  if (labels.length === 0) return null;
  return (
    <div className="mt-3 flex flex-wrap gap-1.5">
      {labels.map((label) => (
        <span
          key={label}
          className="rounded-full bg-cream px-2.5 py-1 text-[11px] text-ink-soft ring-1 ring-line"
        >
          {label}
        </span>
      ))}
    </div>
  );
}

function LetterCard({ letter }: { letter: LetterRow }) {
  const sendReply = useServerFn(replyToLetter);
  const removeLetter = useServerFn(deleteLetter);

  async function onDelete() {
    if (!window.confirm(`Xóa vĩnh viễn lá thư ${letter.code} và toàn bộ cuộc trò chuyện?`)) return;
    const res = await removeLetter({ data: { id: letter.id, token: getToken() } });
    if (res.ok) await router.invalidate();
    else window.alert("Chưa xóa được — thử lại nhé.");
  }
  const router = useRouter();
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(false);

  async function submitReply() {
    if (!draft.trim() || sending) return;
    setSending(true);
    setError(false);
    const res = await sendReply({ data: { id: letter.id, reply: draft.trim(), token: getToken() } });
    setSending(false);
    if (!res.ok) {
      setError(true);
      return;
    }
    setDraft("");
    await router.invalidate();
  }

  return (
    <div className="rounded-[24px] bg-card p-5 ring-1 ring-black/5">
      <div className="flex items-center justify-between gap-3">
        <p className="font-mono text-[14px] font-bold tracking-[0.12em] text-rose-deep">
          {letter.code}
        </p>
        <div className="flex items-center gap-2">
          <p className="text-[11px] text-ink-soft">{formatDate(letter.created_at)}</p>
          <button
            type="button"
            onClick={onDelete}
            aria-label={`Xóa thư ${letter.code}`}
            className="grid size-8 place-items-center rounded-full text-ink-soft ring-1 ring-line transition-colors hover:bg-rose/10 hover:text-rose-deep"
          >
            <Trash2 className="size-3.5" />
          </button>
        </div>
      </div>

      {(letter.student_name || letter.student_class) && (
        <p className="mt-3 rounded-xl bg-sage/20 px-3 py-2 text-[13px] text-ink">
          <span className="font-semibold">{letter.student_name || "(không ghi tên)"}</span>
          {letter.student_class ? ` · Lớp ${letter.student_class}` : ""}
        </p>
      )}

      <AnswerChips answers={letter.answers} />

      <div className="mt-3 space-y-2">
        {letter.thread.map((m, i) => (
          <div key={i} className={m.sender === "support" ? "flex justify-end" : "flex justify-start"}>
            <div className={"max-w-[85%] rounded-2xl px-3.5 py-2.5 " + (m.sender === "support" ? "rounded-br-md bg-rose text-cream" : "rounded-bl-md bg-cream text-ink ring-1 ring-line")}>
              <p className="text-[10px] font-medium opacity-75">{m.sender === "support" ? "Người hỗ trợ" : "Người viết"} · {formatDate(m.at)}</p>
              <p className="mt-0.5 whitespace-pre-wrap text-[14px] leading-relaxed">{m.body || "(Chỉ trả lời các câu hỏi)"}</p>
            </div>
          </div>
        ))}
      </div>

      {letter.contact_email && (
        <p className="mt-3 flex items-center gap-1.5 text-[12px] text-ink-soft">
          <Mail className="size-3.5 text-rose-deep" />
          Người viết để lại email để nhận trả lời trực tiếp: {letter.contact_email}
        </p>
      )}

      {letter.awaitingReply && (
        <p className="mt-3 text-[11px] font-semibold text-rose-deep">● Đang chờ trả lời</p>
      )}
      {(
        <div className="mt-4">
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            maxLength={4000}
            rows={4}
            placeholder="Viết thư trả lời dành cho người với mã này…"
            className="w-full resize-none rounded-2xl bg-cream p-4 text-[14px] leading-relaxed text-ink ring-1 ring-line outline-none transition-shadow placeholder:text-ink-soft/60 focus:ring-2 focus:ring-rose"
          />
          <div className="mt-2 flex items-center justify-between gap-3">
            <p className="text-[11px] text-ink-soft">
              Trả lời sẽ hiện khi người viết nhập mã {letter.code}.
              {letter.contact_email ? " Bạn cũng có thể trả lời thẳng qua email." : ""}
            </p>
            <button
              type="button"
              onClick={submitReply}
              disabled={sending || !draft.trim()}
              className="flex shrink-0 items-center gap-1.5 rounded-full bg-rose px-4 py-2.5 text-[13px] font-semibold text-cream transition-colors active:bg-rose-deep disabled:opacity-40"
            >
              <Send className="size-3.5" />
              {sending ? "Đang gửi…" : "Gửi trả lời"}
            </button>
          </div>
          {error && (
            <p className="mt-1.5 text-[12px] text-rose-deep">
              Chưa gửi được — thử lại nhé.
            </p>
          )}
        </div>
      )}
    </div>
  );
}

function SupportArea() {
  const router = useRouter();
  const unlock = useServerFn(unlockSupport);
  const lock = useServerFn(lockSupport);
  const [password, setPassword] = useState("");
  const [wrong, setWrong] = useState(false);
  const [checking, setChecking] = useState(false);

  const { unlocked, letters } = Route.useLoaderData();

  async function onUnlock(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (checking) return;
    setChecking(true);
    setWrong(false);
    const res = await unlock({ data: { password } });
    setChecking(false);
    if (!res.ok) {
      setWrong(true);
      return;
    }
    try {
      sessionStorage.setItem(TOKEN_KEY, res.token);
    } catch {}
    setPassword("");
    await router.invalidate();
  }

  async function onLock() {
    try {
      sessionStorage.removeItem(TOKEN_KEY);
    } catch {}
    await lock();
    await router.invalidate();
  }

  return (
    <div className="min-h-screen bg-cream text-ink">
      <div className="mx-auto max-w-md px-6 pt-6 pb-12">
        <header className="flex items-center justify-between">
          <p className="font-display text-lg font-semibold tracking-tight">Khu vực người hỗ trợ</p>
          {unlocked && (
            <button
              type="button"
              onClick={onLock}
              className="flex items-center gap-1.5 rounded-full bg-card px-3.5 py-2 text-[12px] font-medium text-ink-soft ring-1 ring-line transition-colors hover:bg-sand"
            >
              <Lock className="size-3.5" />
              Khóa trang
            </button>
          )}
        </header>

        {!unlocked ? (
          <form onSubmit={onUnlock} className="rise mt-16">
            <div className="rounded-[28px] bg-card p-6 ring-1 ring-black/5">
              <span className="grid size-12 place-items-center rounded-2xl bg-rose/15 text-rose-deep">
                <LockOpen className="size-5" />
              </span>
              <h1 className="mt-4 font-display text-[1.5rem] font-semibold tracking-tight">
                Chỉ dành cho người hỗ trợ
              </h1>
              <p className="mt-2 text-[13px] leading-relaxed text-ink-soft">
                Nhập mật khẩu để đọc các lá thư và viết trả lời. Hãy không chia sẻ trang này với bất
                kỳ ai khác.
              </p>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                placeholder="Mật khẩu"
                className="mt-5 w-full rounded-2xl bg-cream p-4 text-[14px] text-ink ring-1 ring-line outline-none transition-shadow focus:ring-2 focus:ring-rose"
              />
              <button
                type="submit"
                disabled={checking || !password}
                className="mt-4 w-full rounded-full bg-rose py-3.5 font-semibold text-[15px] text-cream transition-colors active:bg-rose-deep disabled:opacity-40"
              >
                {checking ? "Đang mở…" : "Mở khu vực hỗ trợ"}
              </button>
              {wrong && (
                <p className="mt-3 text-center text-[12px] text-rose-deep">
                  Mật khẩu chưa đúng — thử lại nhé.
                </p>
              )}
            </div>
          </form>
        ) : (
          <section className="rise mt-8">
            <p className="text-[13px] leading-relaxed text-ink-soft">
              Có {letters.length} lá thư. Trả lời bằng cách viết vào ô dưới mỗi thư — người viết đọc
              được khi nhập mã bí mật của họ.
            </p>
            <div className="mt-5 space-y-4">
              {letters.length === 0 && (
                <div className="rounded-2xl bg-sand p-5 text-center">
                  <p className="text-[13px] font-medium">Chưa có lá thư nào.</p>
                  <p className="mt-1 text-[12px] text-ink-soft">
                    Thư mới sẽ hiện ngay tại đây khi có người niêm phong.
                  </p>
                </div>
              )}
              {letters.map((letter) => (
                <LetterCard key={letter.id} letter={letter} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
